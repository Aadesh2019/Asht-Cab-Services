import UserProfilePage from "../../../components/UserProfile";

export default function ProfilePage() {
  return <UserProfilePage />;
}