-- AlterTable
ALTER TABLE "Booking" ADD COLUMN     "costomemail" TEXT,
ADD COLUMN     "costomercontact" TEXT,
ADD COLUMN     "costomername" TEXT,
ADD COLUMN     "paid" DOUBLE PRECISION;
